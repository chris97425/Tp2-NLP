#Version python 3.5.0

def chrisTrees(hauteur,bool):
    '''
Hauteur:  pour la hauteur de l'arbre
bool: si true permet d'écrire l'arbre dans un fichier texte sinon un print de chrisTrees(10,false) affiche l'arbre en console
addSpace: permet à chaque étape de la boucle "for" d'enlever un espace
christmasTree: résultat final

Démarche: À chaque itération j'enlève un espace et j'ajoute 2 étoiles à l'arbre,
           pour le tronc je précise qu'à chaque fois que je tombe sur un modulo 10 valant
            0 j'incrémente le tronc de 2 et aussi j'augmente ma variable decalForEnd qui me
            permet de savoir combien d'espace j'ai à enlevé.

            '''
    addSpace = hauteur
    baseTree = 1
    decalForEnd = 0
    christmasTree=""
    for i in range(0,hauteur):

        christmasTree += addSpace*" "+i*"*"+"*"+i*"*"+"\n"
        addSpace-=1
        if(i!=0 and i%10==0):

            baseTree+=2
            decalForEnd+=1

    christmasTree+=(hauteur-decalForEnd)*" "+baseTree*"*"

    if (bool):

        file = open("ChrismasTree", "w")
        file.write(christmasTree)

    return christmasTree

print(chrisTrees(133,True))
help(chrisTrees)